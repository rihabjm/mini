import { Component, OnInit } from '@angular/core';
import { MembreService } from '../../Service/membre.service';
import { Membre } from '../../Model/membre';
import { FormGroup, FormControl ,Validators } from '@angular/forms';

@Component({
  selector: 'app-membre-add',
  templateUrl: './membre-add.component.html',
  styleUrls: ['./membre-add.component.css']
})
export class MembreAddComponent implements OnInit {

  constructor(private membreservice: MembreService ) { }
membre : Membre =new Membre() ;
 ngOnInit() {  }
inscrir() {
    this.membreservice.save(this.membre).subscribe( data => {

     if (data.success) {
 } else {}

}, ex => {console.log(ex);
    });
  }


}
