import { Component, OnInit } from '@angular/core';
import {ReunionService} from '../../service/reunion.service' ;
import { Reunion } from '../../Model/reunion';
import { FormsModule, ReactiveFormsModule , FormGroup, FormControl}  from '@angular/forms';


@Component({
  selector: 'app-rensignement-add',
  templateUrl: './rensignement-add.component.html',
  styleUrls: ['./rensignement-add.component.css']
})
export class RensignementAddComponent implements OnInit {

constructor( private reunionservice: ReunionService) { }
reunion : Reunion =new Reunion() ;
 ngOnInit() { }
inscrir() {
    this.reunionservice.save(this.reunion).subscribe( data => {

     if (data.success) {
 } else {}

}, ex => {console.log(ex);
    });
  }

}
