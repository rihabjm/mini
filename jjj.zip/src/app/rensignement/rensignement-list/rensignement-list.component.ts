import { Component, OnInit } from '@angular/core';
import {ReunionService} from '../../service/reunion.service' ;
import { Reunion } from '../../Model/reunion';
import { FormsModule, ReactiveFormsModule , FormGroup, FormControl}  from '@angular/forms';
@Component({
  selector: 'app-rensignement-list',
  templateUrl: './rensignement-list.component.html',
  styleUrls: ['./rensignement-list.component.css']
})
export class RensignementListComponent implements OnInit {
  r: Reunion[] = new Array();

reunion : Reunion ;
  constructor(private reunionservice: ReunionService) { }

  ngOnInit() {  this.getAll () ;

  }
 private getAll() {

  this.reunionservice.getAll().subscribe(data => {
this.r=data ;
      console.log(this.r);
    }, ex => {
      console.log(ex);
    });}

 private chercher(obj : String) {

  this.reunionservice.chercher(obj).subscribe(data => {
this.r=data ;
      console.log(this.r);
    }, ex => {
      console.log(ex);
    });

  }


}
