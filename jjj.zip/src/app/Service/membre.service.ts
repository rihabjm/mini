import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../utils/Config';
import{Membre} from '../Model/Membre'
import {Observable} from 'rxjs';
import { Component, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MembreService {
  private url = Config.BASE_URL + '/membre';

constructor(private httpClient: HttpClient) {}

  public getAll(): Observable<Membre[]> {
    return this.httpClient.get<Membre[]>(this.url);
  }

 public getLocal(): Observable<Membre[]> {
    return this.httpClient.get<Membre[]>(this.url+'/local');
  }

 public getRegioanl(): Observable<Membre[]> {
    return this.httpClient.get<Membre[]>(this.url+'/regional');
  }

 public getNational(): Observable<Membre[]> {
    return this.httpClient.get<Membre[]>(this.url+'/national');
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
 public save(membre: Membre): Observable<any> {

  return this.httpClient.post(this.url+'/add', membre);
  }

 public update(membre:Membre ): Observable<any> {

  return this.httpClient.put(this.url+'/up' , membre);
  }
public valide(membre:Membre ): Observable<any> {

  return this.httpClient.put(this.url+'/valide' , membre);
  }
public droit(membre:Membre ): Observable<any> {

  return this.httpClient.post(Config.BASE_URL+'/agent'+'/droit' , membre);
  }

}
