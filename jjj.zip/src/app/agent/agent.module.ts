import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule , FormGroup, FormControl}  from '@angular/forms';
import { AgentRoutingModule } from './agent-routing.module';
import { AgentDroitComponent } from './agent-droit/agent-droit.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { AgentComponent } from './agent/agent.component';

@NgModule({
  declarations: [AgentDroitComponent, AgentListComponent, AgentComponent],
  imports: [
    CommonModule,
    AgentRoutingModule ,
FormsModule, ReactiveFormsModule
  ]
})
export class AgentModule { }
