import { Component, OnInit } from '@angular/core';
import { MembreService } from '../../Service/membre.service';
import { Membre } from '../../Model/membre';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-agent-droit',
  templateUrl: './agent-droit.component.html',
  styleUrls: ['./agent-droit.component.css']
})
export class AgentDroitComponent implements OnInit {
membre : Membre =new Membre() ;
  constructor(private membreservice: MembreService) { }

  ngOnInit() {
  }
inscrir() {
    this.membreservice.save(this.membre).subscribe( data => {

     if (data.success) {
 } else {}

}, ex => {console.log(ex);
    });
  }
 private droit() {
    this.membreservice.droit(this.membre).subscribe( data => {

     if (data.success) {} else {}
    }, ex => {console.log(ex);
    });
  }

}
